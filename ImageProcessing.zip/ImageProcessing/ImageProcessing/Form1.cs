﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcessing
{
    public partial class Form1 : Form
    {
        int nProcess1;
        string filename = "";
        List<Point> TotIntensityPos;
        public Form1()
        {
            InitializeComponent();
            TotIntensityPos = new List<Point>();

        }

        private void bt_browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"D:\",
                Title = "Open Image Files",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = "jpg",
                Filter = "Image files  (*.bmp;*.jpg;*.jpeg,*.png)|*.BMP;*.JPG;*.JPEG;*.PNG",
                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                filename = openFileDialog1.FileName;
                pb_image.Image = new Bitmap(filename);
            }
        }

        private void bt_process1_Click(object sender, EventArgs e)
        {
            if (filename == "") {
                MessageBox.Show("Select Image file!");
                return;
            }
            pb_image.Image = new Bitmap(filename);
            TotIntensityPos = new List<Point>();
            Process1();
            nProcess1 = 1;
            lb_process1it.Text = nProcess1.ToString();
        }
        private void bt_precess1it_Click(object sender, EventArgs e)
        {
            if (filename == "")
            {
                MessageBox.Show("Select Image!");
                return;
            }
            Process1();
            lb_process1it.Text = "Process 1it";
            nProcess1++;
            lb_process1it.Text = nProcess1.ToString();
        }

        private void bt_process2_Click(object sender, EventArgs e)
        {
            if (filename == "")
            {
                MessageBox.Show("Select Image!");
                return;
            }
            pb_image.Image = new Bitmap(filename);
            Process2();
        }

        /// <summary>
        /// From Now Process 1
        /// </summary>
        private void Process1()
        {
            toolStripStatusLabelProcess.Text = "Process 1 started..";

            int threshold = int.Parse(textBoxIgnoreIntensity.Text);
            // Get your image in a bitmap; this is how to get it from a picturebox
            Bitmap bm = (Bitmap)pb_image.Image;
            // Store the histogram in a dictionary          
            int[] _maxIntn = new int[256];
            int _max;

            for (int i = 0; i < 255; i++) _maxIntn[i] = 0;
            for (int x = 0; x < bm.Width; x++)
            {
                for (int y = 0; y < bm.Height; y++)
                {
                    // Get pixel color 
                    Color c = bm.GetPixel(x, y);
                    // If it exists in our 'histogram' increment the corresponding value, or add new
                    int val = (c.R + c.G + c.B) / 3;
                    _maxIntn[val]++;
                }
            }
			int[] _maxIntn;
			int _max;
					_maxIntn = bm.HistogramGray();
            int _tmp = 0;
            do
            {
                _max = Array.IndexOf(_maxIntn, _maxIntn.Max());
                _tmp = _maxIntn[_max];
                _maxIntn[_max] = 0;
            } while (_max > threshold);
            _maxIntn[_max] = _tmp;

            MaxIntensityPos = GetIntensityPositions(_max, pb_image.Image);
            int nNeibors = int.Parse(tb_neighbors.Text);
            foreach (Point c in MaxIntensityPos) {
                for (int i = -nNeibors; i <= nNeibors; i++) for (int j = -nNeibors; j <= nNeibors; j++) {
                        if (c.X + i < 0 || c.X + i >= bm.Width) continue;
                        if (c.Y + j < 0 || c.Y + j >= bm.Height) continue;
                        bm.SetPixel(c.X + i, c.Y + j, Color.White);
                    }
            }
            TotIntensityPos.AddRange(MaxIntensityPos);

            bm.Save("ResultP1.jpg");
            pb_image.Image = bm;
            toolStripStatusLabelMain.Text = "Max Intensity is " + _max.ToString() + " = " + _maxIntn.Max().ToString() + "iterations.No.Pixels: " + MaxIntensityPos.Count();//+"miniIntensity is " + _min.ToString() + " = " +_maxIntn.Min().ToString() + " iterations";
            toolStripStatusLabelProcess.Text = "Process 1done..";
        }
        public List<Point> GetIntensityPositions(int _CurrentIntensity, Image _img)
        {
            Bitmap sourceImg = new Bitmap(_img);
            List<Point> _IntensityPos = new List<Point>();
            Point _point = new Point();
            for (int i = 0; i < sourceImg.Width; i++) {
                for (int j = 0; j < sourceImg.Height; j++) {
                    Color Spixel = sourceImg.GetPixel(i, j);
                    if (((Spixel.R + Spixel.G + Spixel.B) / 3) == _CurrentIntensity) {
                        _point.X = i; _point.Y = j;
                        _IntensityPos.Add(_point);
                    }
                }
            }
            return _IntensityPos;
        }



        /// <summary>
        /// From Now Process 2
        /// </summary>
        /// <returns></returns>
        public Image Max()
        {
            
            int[] _3x3 = new int[9];
            int _max; int _itns = -1;
            Bitmap sourceImg = new Bitmap(pb_image.Image);
            Bitmap TargetImg = new Bitmap(pb_image.Image.Width, pb_image.Image.Height);
            Color Spixel;
            int _ind = 0;
            for (int i = 1; i < sourceImg.Height - 1; i++)
                for (int j = 1; j < sourceImg.Width - 1; j++)
                {
                    int _i = 0;
                    for (int v = -1; v < 2; v++)
                        for (int h = -1; h < 2; h++)
                        {
                            Spixel = sourceImg.GetPixel(j + h, i + v);
                            _itns = (Spixel.R + Spixel.G + Spixel.B) / 3;
                            _3x3[_i] = _itns;
                            _i++;
                            _ind++;
                        }
                    if (_3x3[4] == -1)
                        _max = 255;
                    else
                        _max = _3x3.Max();
                    TargetImg.SetPixel(j, i, Color.FromArgb(_max, _max, _max));
                    _ind = 0;
                }
            return TargetImg;
        }

        private void Process2()
        {
            toolStripStatusLabelProcess.Text = "Process 2 started..";
            int ite = int.Parse(textBoxP2Iteration.Text);
            if (ite > 0)
                {
                    for (int i = 0; i < ite; i++) pb_image.Image=Max();
                    pb_image.Image.Save("ResultP2.I" + textBoxP2Iteration.Text + ".jpg");
                }
                toolStripStatusLabelProcess.Text = "Process 2 done..";
            }

        private void bt_combine_Click(object sender, EventArgs e)
        {
            /*            Bitmap b1 = new Bitmap("ResultP1.jpg");
                        Bitmap b2 = new Bitmap("ResultP2.I" + textBoxP2Iteration.Text + ".jpg");

                        for (int i = 0; i < b2.Width; i++)
                            for (int j = 0; j < b2.Height; j++) {
                                Color c = b1.GetPixel(i, j);
                                if (c.R == 255 && c.G == 255 && c.B == 255)
                                {
                                    b2.SetPixel(i, j, Color.Black);
                                }
                            }*/
            Bitmap b2 = new Bitmap("ResultP2.I" + textBoxP2Iteration.Text + ".jpg");
            int nNeibors = int.Parse(tb_neighbors.Text);
            foreach (Point c in TotIntensityPos)
            {
                for (int i = -nNeibors; i <= nNeibors; i++) for (int j = -nNeibors; j <= nNeibors; j++)
                    {
                        if (c.X + i < 0 || c.X + i >= b2.Width) continue;
                        if (c.Y + j < 0 || c.Y + j >= b2.Height) continue;
                        b2.SetPixel(c.X + i, c.Y + j, Color.White);
                    }
            }

            pb_image.Image = b2;
            b2.Save("Combined.jpg");
            toolStripStatusLabelProcess.Text = "Process 2 Combined..";
        }

    }
}
