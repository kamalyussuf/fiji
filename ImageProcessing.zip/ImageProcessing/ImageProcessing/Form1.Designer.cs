﻿namespace ImageProcessing
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pb_image = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxIgnoreIntensity = new System.Windows.Forms.TextBox();
            this.tb_neighbors = new System.Windows.Forms.TextBox();
            this.textBoxP2Iteration = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_process1it = new System.Windows.Forms.Label();
            this.bt_combine = new System.Windows.Forms.Button();
            this.bt_process2 = new System.Windows.Forms.Button();
            this.bt_precess1it = new System.Windows.Forms.Button();
            this.bt_process1 = new System.Windows.Forms.Button();
            this.bt_browse = new System.Windows.Forms.Button();
            this.toolStripStatusLabelMain = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.toolStripStatusLabelProcess = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pb_image)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pb_image
            // 
            this.pb_image.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_image.Location = new System.Drawing.Point(3, 3);
            this.pb_image.Name = "pb_image";
            this.pb_image.Size = new System.Drawing.Size(957, 488);
            this.pb_image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pb_image.TabIndex = 0;
            this.pb_image.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxIgnoreIntensity);
            this.groupBox1.Controls.Add(this.tb_neighbors);
            this.groupBox1.Controls.Add(this.textBoxP2Iteration);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lb_process1it);
            this.groupBox1.Controls.Add(this.bt_combine);
            this.groupBox1.Controls.Add(this.bt_process2);
            this.groupBox1.Controls.Add(this.bt_precess1it);
            this.groupBox1.Controls.Add(this.bt_process1);
            this.groupBox1.Controls.Add(this.bt_browse);
            this.groupBox1.Location = new System.Drawing.Point(12, 506);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(959, 127);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Controls";
            // 
            // textBoxIgnoreIntensity
            // 
            this.textBoxIgnoreIntensity.Location = new System.Drawing.Point(179, 98);
            this.textBoxIgnoreIntensity.Name = "textBoxIgnoreIntensity";
            this.textBoxIgnoreIntensity.Size = new System.Drawing.Size(28, 20);
            this.textBoxIgnoreIntensity.TabIndex = 2;
            this.textBoxIgnoreIntensity.Text = "90";
            // 
            // tb_neighbors
            // 
            this.tb_neighbors.Location = new System.Drawing.Point(228, 76);
            this.tb_neighbors.Name = "tb_neighbors";
            this.tb_neighbors.Size = new System.Drawing.Size(28, 20);
            this.tb_neighbors.TabIndex = 2;
            this.tb_neighbors.Text = "1";
            // 
            // textBoxP2Iteration
            // 
            this.textBoxP2Iteration.Location = new System.Drawing.Point(414, 22);
            this.textBoxP2Iteration.Name = "textBoxP2Iteration";
            this.textBoxP2Iteration.Size = new System.Drawing.Size(28, 20);
            this.textBoxP2Iteration.TabIndex = 2;
            this.textBoxP2Iteration.Text = "1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Ignore Intensity more than";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(114, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number Of Neighbors!";
            // 
            // lb_process1it
            // 
            this.lb_process1it.AutoSize = true;
            this.lb_process1it.Location = new System.Drawing.Point(235, 54);
            this.lb_process1it.Name = "lb_process1it";
            this.lb_process1it.Size = new System.Drawing.Size(13, 13);
            this.lb_process1it.TabIndex = 1;
            this.lb_process1it.Text = "0";
            // 
            // bt_combine
            // 
            this.bt_combine.Location = new System.Drawing.Point(695, 20);
            this.bt_combine.Name = "bt_combine";
            this.bt_combine.Size = new System.Drawing.Size(75, 23);
            this.bt_combine.TabIndex = 0;
            this.bt_combine.Text = "Combine";
            this.bt_combine.UseVisualStyleBackColor = true;
            this.bt_combine.Click += new System.EventHandler(this.bt_combine_Click);
            // 
            // bt_process2
            // 
            this.bt_process2.Location = new System.Drawing.Point(315, 20);
            this.bt_process2.Name = "bt_process2";
            this.bt_process2.Size = new System.Drawing.Size(75, 23);
            this.bt_process2.TabIndex = 0;
            this.bt_process2.Text = "Process2";
            this.bt_process2.UseVisualStyleBackColor = true;
            this.bt_process2.Click += new System.EventHandler(this.bt_process2_Click);
            // 
            // bt_precess1it
            // 
            this.bt_precess1it.Location = new System.Drawing.Point(141, 49);
            this.bt_precess1it.Name = "bt_precess1it";
            this.bt_precess1it.Size = new System.Drawing.Size(75, 23);
            this.bt_precess1it.TabIndex = 0;
            this.bt_precess1it.Text = "Process 1It";
            this.bt_precess1it.UseVisualStyleBackColor = true;
            this.bt_precess1it.Click += new System.EventHandler(this.bt_precess1it_Click);
            // 
            // bt_process1
            // 
            this.bt_process1.Location = new System.Drawing.Point(141, 20);
            this.bt_process1.Name = "bt_process1";
            this.bt_process1.Size = new System.Drawing.Size(75, 23);
            this.bt_process1.TabIndex = 0;
            this.bt_process1.Text = "Process1";
            this.bt_process1.UseVisualStyleBackColor = true;
            this.bt_process1.Click += new System.EventHandler(this.bt_process1_Click);
            // 
            // bt_browse
            // 
            this.bt_browse.Location = new System.Drawing.Point(35, 20);
            this.bt_browse.Name = "bt_browse";
            this.bt_browse.Size = new System.Drawing.Size(75, 23);
            this.bt_browse.TabIndex = 0;
		this.bt_browse.Text = "Select";
            this.bt_browse.UseVisualStyleBackColor = true;
            this.bt_browse.Click += new System.EventHandler(this.bt_browse_Click);
            // 
            // toolStripStatusLabelMain
            // 
            this.toolStripStatusLabelMain.AutoSize = true;
            this.toolStripStatusLabelMain.Location = new System.Drawing.Point(27, 644);
            this.toolStripStatusLabelMain.Name = "toolStripStatusLabelMain";
            this.toolStripStatusLabelMain.Size = new System.Drawing.Size(269, 13);
            this.toolStripStatusLabelMain.TabIndex = 1;
            this.toolStripStatusLabelMain.Text = "mainInfo                                                                         " +
    " ";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.pb_image);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(959, 488);
            this.panel1.TabIndex = 2;
            // 
            // toolStripStatusLabelProcess
            // 
            this.toolStripStatusLabelProcess.AutoSize = true;
            this.toolStripStatusLabelProcess.Location = new System.Drawing.Point(27, 661);
            this.toolStripStatusLabelProcess.Name = "toolStripStatusLabelProcess";
            this.toolStripStatusLabelProcess.Size = new System.Drawing.Size(261, 13);
            this.toolStripStatusLabelProcess.TabIndex = 1;
            this.toolStripStatusLabelProcess.Text = "ProcessInfo                                                                  ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 780);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStripStatusLabelProcess);
            this.Controls.Add(this.toolStripStatusLabelMain);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "RMFC FRAUD DETECTION";
            ((System.ComponentModel.ISupportInitialize)(this.pb_image)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_image;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxIgnoreIntensity;
        private System.Windows.Forms.TextBox tb_neighbors;
        private System.Windows.Forms.TextBox textBoxP2Iteration;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_process1it;
        private System.Windows.Forms.Button bt_combine;
        private System.Windows.Forms.Button bt_process2;
        private System.Windows.Forms.Button bt_precess1it;
        private System.Windows.Forms.Button bt_process1;
        private System.Windows.Forms.Button bt_browse;
        private System.Windows.Forms.Label toolStripStatusLabelMain;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label toolStripStatusLabelProcess;
    }
}

